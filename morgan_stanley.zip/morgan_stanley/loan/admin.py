from django.contrib import admin
from .models import LoanDetails


class LoanDetailsAdmin(admin.ModelAdmin):
    list_display = ('loan_id','customer_name','loan_category','email','mobile','address')


admin.site.register(LoanDetails,LoanDetailsAdmin)