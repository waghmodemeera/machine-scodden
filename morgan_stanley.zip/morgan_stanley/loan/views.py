from django.shortcuts import render
from .models import LoanDetails
# Create your views here.
def show_loan_details(r):
    loan_list = LoanDetails.objects.all() # ORM Query
    #select * from LoanDetails SQL Query
    loan_data = {'loan_list':loan_list}
    return render(r,'loan/loandetails.html',context=loan_data)
