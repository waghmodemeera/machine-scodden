from django.db import models

class LoanDetails(models.Model):
    PERSONAL = "PR"
    BUSSINESS = "BL"
    HOMELOAN = "HL"

    LOAN_IN_CHOICES = [
        (PERSONAL, "Personal Loan"),
        (BUSSINESS, "Bussiness Loan"),
        (HOMELOAN, "Home Loan"),

    ]

    loan_id = models.IntegerField()
    customer_name = models.CharField(max_length=20)
    loan_category = models.CharField(
        max_length=2,
        choices=LOAN_IN_CHOICES,
        default=PERSONAL,
    )
    email = models.EmailField()
    mobile = models.IntegerField()
    address = models.CharField(max_length=35)

